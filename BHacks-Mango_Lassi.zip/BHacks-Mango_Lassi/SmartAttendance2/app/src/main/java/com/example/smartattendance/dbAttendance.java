package com.example.smartattendance;

import java.util.ArrayList;

public class dbAttendance {
    String courseId;
    String date;
    ArrayList<dbRollnumber> rollnumbers;
    int weight;
    int isSynced;
}
