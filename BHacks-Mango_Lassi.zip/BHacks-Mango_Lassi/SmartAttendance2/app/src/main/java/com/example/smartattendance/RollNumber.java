package com.example.smartattendance;

public class RollNumber {
    String Suffix;
    int from;
    int to;
    public RollNumber() {

    }


    public RollNumber(String suffix, int from, int to) {
        Suffix = suffix;
        this.from = from;
        this.to = to;
    }
}
