package com.example.smartattendance;

public class dbCourseStudent {
    String Course;
    String name;
}
